<?php $__env->startSection('title', 'valo – Strona główna'); ?>

<?php $__env->startSection('content'); ?>
    <div class="home-hero">
        <div class="home-logo">
            <?php if(file_exists(public_path('logo.png'))): ?>
                <img src="<?php echo e(asset('logo.png')); ?>" alt="valo" class="home-logo-img" />
            <?php elseif(file_exists(public_path('logo.svg'))): ?>
                <img src="<?php echo e(asset('logo.svg')); ?>" alt="valo" class="home-logo-img" />
            <?php else: ?>
                <span class="home-logo-text">valo</span>
            <?php endif; ?>
        </div>
        <div class="home-slogan">
            <p>Raport P&L, import danych i plan kont — wszystko w jednym miejscu.</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/piotr/Documents/3.SOFTWARE/_syto/valo/resources/views/welcome.blade.php ENDPATH**/ ?>