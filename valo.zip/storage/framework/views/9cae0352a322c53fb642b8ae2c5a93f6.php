<?php $__env->startSection('title', 'Raport P&L – ' . ($import->okres_nazwa ?? '') . ' – ' . config('app.name')); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content page-content--wide">
        <div class="page-header">
            <h1 class="page-title">Raport P&L</h1>
        </div>
        <div class="mb-4 flex flex-wrap items-center gap-4">
            <label for="raport-pl-okres" class="text-sm font-medium text-[#1b1b18] dark:text-[#EDEDEC]">Okres:</label>
            <select id="raport-pl-okres" class="form-input w-auto min-w-[16rem]" onchange="window.location=this.value">
                <?php $__currentLoopData = $imports ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e(route('raport-pl.show', $imp)); ?>" <?php echo e($imp->id === $import->id ? 'selected' : ''); ?>>
                        <?php echo e($imp->okres_nazwa ?? '—'); ?> (import <?php echo e($imp->created_at->format('Y-m-d H:i')); ?>, <?php echo e($imp->dane_count); ?> wierszy)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">Import: okres <?php echo e($import->okres_nazwa ?? '—'); ?>, zaimportowano <?php echo e($import->created_at->format('Y-m-d H:i')); ?>. % plan bieżący = narastająco/(plan × <?php echo e($miesiac ?? 12); ?>/12). Kolumny miesięczne = różnica vs poprzedni miesiąc.</p>
        <div class="table-wrap overflow-x-auto w-full max-w-none mb-8">
            <table class="data-table raport-pl-table">
                <thead>
                    <tr>
                        <th>Kategoria</th>
                        <th class="text-right">Plan</th>
                        <th class="text-right">% plan bieżący</th>
                        <th class="text-right">Narastająco</th>
                        <?php for($m = ($miesiac ?? 12); $m >= 1; $m--): ?>
                        <th class="text-right"><?php echo e(['Styczeń','Luty','Marzec','Kwiecień','Maj','Czerwiec','Lipiec','Sierpień','Wrzesień','Październik','Listopad','Grudzień'][$m-1]); ?></th>
                        <?php endfor; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $wiersze; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($w['typ'] === 'podsumowanie_sales'): ?>
                    <?php
                        $plan = $w['plan'] ?? null;
                        $pctTotal = ($plan !== null && $plan != 0) ? ($w['narastajaco'] / $plan) * 100 : null;
                        $pctBiezacy = ($plan !== null && $plan != 0 && ($miesiac ?? 12) > 0) ? ($w['narastajaco'] / ($plan * ($miesiac ?? 12) / 12)) * 100 : null;
                    ?>
                    <tr class="raport-pl-naglowek-grupy">
                        <td><strong>Total Sales</strong></td>
                        <td class="text-right"><?php echo e(isset($w['plan']) && $w['plan'] !== null ? number_format($w['plan'], 2, ',', ' ') : '—'); ?></td>
                        <td class="text-right"><?php echo e($pctBiezacy !== null ? number_format($pctBiezacy, 1, ',', ' ') . '%' : '—'); ?></td>
                        <td class="text-right"><strong><?php echo e(number_format($w['narastajaco'], 2, ',', ' ')); ?></strong></td>
                        <?php for($m = ($miesiac ?? 12); $m >= 1; $m--): ?>
                        <td class="text-right">
                            <?php $val = $w['wartosci_miesieczne'][$m] ?? null; ?>
                            <?php if($val !== null): ?>
                                <?php if($m === ($miesiac ?? 0)): ?><strong><?php endif; ?><?php echo e(number_format($val, 2, ',', ' ')); ?><?php if($m === ($miesiac ?? 0)): ?></strong><?php endif; ?>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                        <?php endfor; ?>
                    </tr>
                    <?php elseif($w['typ'] === 'podsumowanie_oper_result'): ?>
                    <?php
                        $plan = $w['plan'] ?? null;
                        $pctTotal = ($plan !== null && $plan != 0) ? ($w['narastajaco'] / $plan) * 100 : null;
                        $pctBiezacy = ($plan !== null && $plan != 0 && ($miesiac ?? 12) > 0) ? ($w['narastajaco'] / ($plan * ($miesiac ?? 12) / 12)) * 100 : null;
                    ?>
                    <tr class="raport-pl-naglowek-grupy">
                        <td style="display: flex; justify-content: flex-end; align-items: center;"><strong>Total Operational Result</strong> <span class="raport-pl-oper-result-label">(Margin1 - Direct)</span></td>
                        <td class="text-right"><?php echo e(isset($w['plan']) && $w['plan'] !== null ? number_format($w['plan'], 2, ',', ' ') : '—'); ?></td>
                        <td class="text-right"><?php echo e($pctBiezacy !== null ? number_format($pctBiezacy, 1, ',', ' ') . '%' : '—'); ?></td>
                        <td class="text-right"><strong><?php echo e(number_format($w['narastajaco'], 2, ',', ' ')); ?></strong></td>
                        <?php for($m = ($miesiac ?? 12); $m >= 1; $m--): ?>
                        <td class="text-right">
                            <?php $val = $w['wartosci_miesieczne'][$m] ?? null; ?>
                            <?php if($val !== null): ?>
                                <?php if($m === ($miesiac ?? 0)): ?><strong><?php endif; ?><?php echo e(number_format($val, 2, ',', ' ')); ?><?php if($m === ($miesiac ?? 0)): ?></strong><?php endif; ?>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                        <?php endfor; ?>
                    </tr>
                    <?php elseif($w['typ'] === 'naglowek_grupy'): ?>
                    <?php
                        $plan = $w['oper_result_plan'] ?? null;
                        $pctTotal = ($plan !== null && $plan != 0) ? (($w['oper_result_narastajaco'] ?? 0) / $plan) * 100 : null;
                        $pctBiezacy = ($plan !== null && $plan != 0 && ($miesiac ?? 12) > 0) ? (($w['oper_result_narastajaco'] ?? 0) / ($plan * ($miesiac ?? 12) / 12)) * 100 : null;
                    ?>
                    <tr class="raport-pl-naglowek-grupy">
                        <td style="display: flex; justify-content: space-between; align-items: center;">
                            <span>
                                <?php if(isset($w['grupa_idx'])): ?>
                                <span class="raport-pl-expand raport-pl-grupa-expand" role="button" tabindex="0" onclick="var r=document.querySelectorAll('.raport-pl-grupa-details-<?php echo e($w['grupa_idx']); ?>'); r.forEach(function(x){x.classList.toggle('raport-pl-grupa-ukryta');}); this.textContent=this.textContent==='>'?'v':'>'" title="Rozwiń/zwiń szczegóły">&gt;</span>
                                <?php endif; ?>
                                <strong><?php echo e($w['grupa']); ?></strong>
                            </span>
                            <?php if(isset($w['oper_result_biezacy'])): ?>
                            <span class="raport-pl-oper-result-label">— Operational Result (Margin1 - Direct)</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-right"><?php if(isset($w['oper_result_plan']) && $w['oper_result_plan'] !== null): ?><?php echo e(number_format($w['oper_result_plan'], 2, ',', ' ')); ?><?php else: ?>—<?php endif; ?></td>
                        <td class="text-right"><?php if($pctBiezacy !== null): ?><?php echo e(number_format($pctBiezacy, 1, ',', ' ')); ?>%<?php else: ?>—<?php endif; ?></td>
                        <td class="text-right"><?php if(isset($w['oper_result_narastajaco'])): ?><strong><?php echo e(number_format($w['oper_result_narastajaco'], 2, ',', ' ')); ?></strong><?php else: ?>—<?php endif; ?></td>
                        <?php for($m = ($miesiac ?? 12); $m >= 1; $m--): ?>
                        <td class="text-right">
                            <?php $val = $w['wartosci_miesieczne'][$m] ?? null; ?>
                            <?php if($val !== null): ?>
                                <?php if($m === ($miesiac ?? 0)): ?><strong><?php endif; ?><?php echo e(number_format($val, 2, ',', ' ')); ?><?php if($m === ($miesiac ?? 0)): ?></strong><?php endif; ?>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                        <?php endfor; ?>
                    </tr>
                    <?php else: ?>
                    <?php echo $__env->make('raport-pl._wiersz', ['w' => $w, 'loop' => $loop, 'miesiac' => $miesiac ?? 12], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/piotr/Documents/3.SOFTWARE/_syto/valo/resources/views/raport-pl/show.blade.php ENDPATH**/ ?>