<?php $__env->startSection('title', 'Plan kont – ' . config('app.name')); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content page-content--wide">
    <div class="page-header">
        <h1 class="page-title">Plan kont</h1>
        <div class="page-actions">
            <a href="<?php echo e(route('plan-kont.create')); ?>" class="btn btn-primary">Dodaj</a>
            <a href="<?php echo e(route('plan-kont.pobierz-csv')); ?>" class="btn btn-outline">Pobierz CSV</a>
            <form action="<?php echo e(route('plan-kont.przyjmij-grupy')); ?>" method="POST" class="inline-form">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-outline">Przypisz grupy</button>
            </form>
            <form id="form-usun-wszystko" action="<?php echo e(route('plan-kont.destroy-all')); ?>" method="POST" class="inline-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="confirm" value="1">
                <input type="hidden" name="potwierdzenie" value="" id="potwierdzenie-usun">
                <button type="button" class="btn btn-danger" id="btn-usun-wszystko">Usuń wszystko</button>
            </form>
            <script>
                document.getElementById('btn-usun-wszystko').addEventListener('click', function() {
                    if (!confirm('Czy na pewno usunąć wszystkie pozycje planu kont?')) return;
                    var w = prompt('Aby potwierdzić, wpisz słownie: TAK');
                    if (w !== null && w.trim().toUpperCase() === 'TAK') {
                        document.getElementById('potwierdzenie-usun').value = 'TAK';
                        document.getElementById('form-usun-wszystko').submit();
                    }
                });
            </script>
        </div>
    </div>

    <?php if(session('success')): ?>
        <p class="alert alert-success"><?php echo e(session('success')); ?></p>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <p class="alert-danger"><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    <?php if($items->isEmpty()): ?>
        <p class="empty-state">Brak pozycji w planie kont. <a href="<?php echo e(route('plan-kont.create')); ?>">Dodaj pierwszą pozycję</a>.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Nr</th>
                        <th>Grupa</th>
                        <th>Nazwa</th>
                        <th>Rodzaj pozycji</th>
                        <th class="col-actions">Akcje</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->nr); ?></td>
                        <td><?php echo e($item->grupa); ?></td>
                        <td><?php echo e($item->nazwa); ?></td>
                        <td><?php echo e($item->rodzaj_pozycji); ?></td>
                        <td class="col-actions">
                            <a href="<?php echo e(route('plan-kont.edit', $item)); ?>" class="btn-icon" title="Edytuj">
                                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125"/></svg>
                            </a>
                            <form action="<?php echo e(route('plan-kont.destroy', $item)); ?>" method="POST" class="inline-form" onsubmit="return confirm('Usunąć tę pozycję?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-icon btn-icon--danger" title="Usuń">
                                    <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"/></svg>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/piotr/Documents/3.SOFTWARE/_syto/valo/resources/views/plan-kont/index.blade.php ENDPATH**/ ?>