<?php
    $klasa = trim((!empty($w['pogrubiony']) && !isset($w['grupa_idx']) ? 'raport-pl-pogrubiony ' : '') . (isset($w['grupa_idx']) ? 'raport-pl-grupa-details raport-pl-grupa-details-' . $w['grupa_idx'] . ' raport-pl-grupa-ukryta' : ''));
    $sumaRight = in_array($w['kategoria'] ?? '', ['Margin1 (suma ze wszystkich grup)', 'Direct (suma ze wszystkich grup)'], true);
    if ($sumaRight) { $klasa .= ' raport-pl-suma-row'; }
    $marginRight = isset($w['grupa_idx']) && ($w['kategoria'] ?? '') === 'Margin1';
    $ebitRight = ($w['kategoria'] ?? '') === 'EBIT';
    $incomeRight = ($w['kategoria'] ?? '') === 'Income';
    $plan = $w['plan'] ?? null;
    $miesiac = $miesiac ?? 12;
    $pctTotal = ($plan !== null && $plan != 0) ? (($w['narastajaco'] ?? 0) / $plan) * 100 : null;
    $pctBiezacy = ($plan !== null && $plan != 0 && $miesiac > 0) ? (($w['narastajaco'] ?? 0) / ($plan * $miesiac / 12)) * 100 : null;
?>
<?php
    $pozycje = $w['pozycje'] ?? [];
    $summaryRowStyle = in_array($w['kategoria'] ?? '', ['Indirect', 'Financial', 'Koszty ogólne Direct (bez grupy)'], true);
?>
<?php if(!empty($pozycje) || $summaryRowStyle): ?>
<tr class="<?php echo e($klasa); ?>">
    <td style="<?php echo e($marginRight ? 'display:flex; justify-content:space-between; align-items:center; padding-left:1.5rem;' : ($summaryRowStyle ? 'display:flex; justify-content:flex-start; align-items:center;' : 'padding-left:1.5rem;')); ?>">
        <span>
            <span class="raport-pl-expand" role="button" tabindex="0" onclick="document.getElementById('raport-pl-details-<?php echo e($loop->index); ?>').classList.toggle('raport-pl-pozycje-widoczne'); this.textContent = this.textContent === '>' ? 'v' : '>'" title="Pokaż pozycje">&gt;</span>
            <?php if(!$marginRight): ?><?php echo e($w['kategoria']); ?><?php echo e(($w['kategoria'] ?? '') === 'Margin1' ? ' (Sales - CoS)' : ''); ?><?php endif; ?>
        </span>
        <?php if($marginRight): ?><span><?php echo e($w['kategoria']); ?> (Sales - CoS)</span><?php endif; ?>
    </td>
    <td class="text-right"><?php echo e($w['plan'] !== null ? number_format($w['plan'], 2, ',', ' ') : '—'); ?></td>
    <td class="text-right"><?php echo e($pctBiezacy !== null ? number_format($pctBiezacy, 1, ',', ' ') . '%' : '—'); ?></td>
    <td class="text-right"><?php echo e(number_format($w['narastajaco'], 2, ',', ' ')); ?></td>
    <?php for($m = $miesiac; $m >= 1; $m--): ?>
    <td class="text-right">
        <?php $val = $w['wartosci_miesieczne'][$m] ?? null; ?>
        <?php if($val !== null): ?>
            <?php if($m === $miesiac && !empty($w['pogrubiony'])): ?><strong><?php endif; ?><?php echo e(number_format($val, 2, ',', ' ')); ?><?php if($m === $miesiac && !empty($w['pogrubiony'])): ?></strong><?php endif; ?>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>
    <?php endfor; ?>
</tr>
<tr id="raport-pl-details-<?php echo e($loop->index); ?>" class="raport-pl-pozycje-row <?php echo e(isset($w['grupa_idx']) ? 'raport-pl-grupa-details raport-pl-grupa-details-' . $w['grupa_idx'] . ' raport-pl-grupa-ukryta' : ''); ?>">
    <td colspan="<?php echo e(4 + $miesiac); ?>" class="raport-pl-pozycje-cell">
        <div class="raport-pl-pozycje-list">
            <table class="raport-pl-pozycje-table">
                <thead>
                    <tr>
                        <th>Nr</th>
                        <th>Nazwa</th>
                        <?php for($m = $miesiac; $m >= 1; $m--): ?>
                        <th class="text-right"><?php echo e(['Styczeń','Luty','Marzec','Kwiecień','Maj','Czerwiec','Lipiec','Sierpień','Wrzesień','Październik','Listopad','Grudzień'][$m-1]); ?></th>
                        <?php endfor; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pozycje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($p['nr']); ?></td>
                        <td><?php echo e($p['nazwa']); ?></td>
                        <?php for($m = $miesiac; $m >= 1; $m--): ?>
                        <td class="text-right">
                            <?php $val = $p['wartosci_miesieczne'][$m] ?? null; ?>
                            <?php if($val !== null): ?>
                                <?php echo e(number_format($val, 2, ',', ' ')); ?>

                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                        <?php endfor; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </td>
</tr>
<?php else: ?>
<tr class="<?php echo e($klasa); ?>">
    <td style="padding-left:1.5rem;<?php echo e(($marginRight || $ebitRight || $incomeRight || $sumaRight) ? ' text-align:right;' : ''); ?>"><?php echo e($w['kategoria']); ?><?php echo e(($w['kategoria'] ?? '') === 'Margin1' ? ' (Sales - CoS)' : ''); ?><?php echo e($ebitRight ? ' (Operational Result - Indirect)' : ''); ?><?php echo e($incomeRight ? ' (EBIT - Financial)' : ''); ?></td>
    <td class="text-right"><?php echo e($w['plan'] !== null ? number_format($w['plan'], 2, ',', ' ') : '—'); ?></td>
    <td class="text-right"><?php echo e($pctBiezacy !== null ? number_format($pctBiezacy, 1, ',', ' ') . '%' : '—'); ?></td>
    <td class="text-right"><?php echo e(number_format($w['narastajaco'], 2, ',', ' ')); ?></td>
    <?php for($m = $miesiac; $m >= 1; $m--): ?>
    <td class="text-right">
        <?php $val = $w['wartosci_miesieczne'][$m] ?? null; ?>
        <?php if($val !== null): ?>
            <?php if($m === $miesiac && !empty($w['pogrubiony'])): ?><strong><?php endif; ?><?php echo e(number_format($val, 2, ',', ' ')); ?><?php if($m === $miesiac && !empty($w['pogrubiony'])): ?></strong><?php endif; ?>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>
    <?php endfor; ?>
</tr>
<?php endif; ?>
<?php /**PATH /Users/piotr/Documents/3.SOFTWARE/_syto/valo/resources/views/raport-pl/_wiersz.blade.php ENDPATH**/ ?>