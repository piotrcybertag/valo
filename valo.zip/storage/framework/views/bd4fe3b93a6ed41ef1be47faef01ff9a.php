<?php $__env->startSection('title', 'Logowanie – ' . config('app.name')); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content login-page">
    <div class="login-layout">
        <div class="login-form-col">
            <div class="page-header">
                <h1 class="page-title">Logowanie</h1>
            </div>

            <form action="<?php echo e(route('login')); ?>" method="POST" class="form-card">
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="email" class="form-input">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="form-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-row">
                    <label for="password">Hasło</label>
                    <input type="password" name="password" id="password" required autocomplete="current-password" class="form-input">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="form-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-row">
                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="remember" class="rounded border-gray-300">
                        <span class="text-sm">Zapamiętaj mnie</span>
                    </label>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Zaloguj</button>
                </div>
            </form>
        </div>
        <div class="login-logo-col">
            <?php if(file_exists(public_path('logo.png'))): ?>
                <img src="<?php echo e(asset('logo.png')); ?>" alt="valo" class="login-logo" />
            <?php elseif(file_exists(public_path('logo.svg'))): ?>
                <img src="<?php echo e(asset('logo.svg')); ?>" alt="valo" class="login-logo" />
            <?php else: ?>
                <span class="login-logo-fallback">valo</span>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/piotr/Documents/3.SOFTWARE/_syto/valo/resources/views/auth/login.blade.php ENDPATH**/ ?>