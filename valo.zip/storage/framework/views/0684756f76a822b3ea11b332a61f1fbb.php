<?php $__env->startSection('title', 'Raport P&L – ' . config('app.name')); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="page-header">
            <h1 class="page-title">Raport P&L</h1>
        </div>
        <div class="rounded-lg border border-[#e3e3e0] dark:border-[#3E3E3A] bg-white dark:bg-[#161615] p-6 shadow-sm max-w-lg">
            <p class="text-[#1b1b18] dark:text-[#EDEDEC] mb-4">Wybierz import, z którego zrobić raport:</p>
            <?php if($imports->isEmpty()): ?>
                <p class="text-sm text-gray-500 dark:text-gray-400">Brak importów danych. <a href="<?php echo e(route('import.index')); ?>" class="text-[#1e3a5f] underline">Zaimportuj dane</a> w sekcji Import.</p>
            <?php else: ?>
                <form action="<?php echo e(route('raport-pl.index')); ?>" method="get" class="space-y-4">
                    <div class="form-row">
                        <label for="import_id" class="block text-sm font-medium text-[#1b1b18] dark:text-[#EDEDEC] mb-1">Import</label>
                        <select name="import_id" id="import_id" required class="form-input">
                            <option value="">— wybierz import —</option>
                            <?php $__currentLoopData = $imports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($imp->id); ?>">
                                    <?php echo e($imp->okres_nazwa ?? '—'); ?> (import <?php echo e($imp->created_at->format('Y-m-d H:i')); ?>, <?php echo e($imp->dane_count); ?> wierszy)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Pokaż raport</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/piotr/Documents/3.SOFTWARE/_syto/valo/resources/views/raport-pl/index.blade.php ENDPATH**/ ?>