<?php $__env->startSection('title', 'Piątki – przegląd – ' . config('app.name')); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content page-content--wide">
    <div class="page-header">
        <h1 class="page-title">Piątki – przegląd danych</h1>
        <a href="<?php echo e(route('piatki.index')); ?>" class="btn btn-outline">← Powrót do listy</a>
    </div>

    <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">Import: <?php echo e($importProjekt->nazwa_pliku ?? '—'); ?>, zaimportowano <?php echo e($importProjekt->created_at->format('Y-m-d H:i')); ?>, <?php echo e($importProjekt->dane->count()); ?> wierszy.</p>

    <?php
        $grupy = [];
        foreach ($importProjekt->dane as $d) {
            $nazwa = $d->nazwa ?? '';
            if (!isset($grupy[$nazwa])) {
                $grupy[$nazwa] = ['wn3' => 0.0, 'ma3' => 0.0, 'szczegoly' => []];
            }
            $w = $d->wartosci ?? [];
            $wn3 = (float) ($w['wn3'] ?? 0);
            $ma3 = (float) ($w['ma3'] ?? 0);
            $grupy[$nazwa]['wn3'] += $wn3;
            $grupy[$nazwa]['ma3'] += $ma3;
            $grupy[$nazwa]['szczegoly'][] = ['nr' => $d->nr, 'wn3' => $wn3, 'ma3' => $ma3];
        }
    ?>

    <style>
        .piatki-expand { display:inline-block; width:1.25rem; cursor:pointer; font-weight:700; color:#1e3a5f; user-select:none; }
        .piatki-expand:hover { color:#16304d; }
        .piatki-details-row { display:none; }
        .piatki-details-row.piatki-details-widoczne { display:table-row; }
        .piatki-details-cell { padding:0.5rem 1rem 1rem 3rem !important; background:#f9fafb; font-size:.75rem; }
        .piatki-details-table { width:100%; border-collapse:collapse; font-size:.75rem; }
        .piatki-details-table th, .piatki-details-table td { padding:.25rem .5rem; text-align:left; border:none; }
        .piatki-details-table th { font-weight:600; color:#6b7280; }
        .piatki-num { font-family: ui-monospace, 'Cascadia Code', 'Source Code Pro', Menlo, Consolas, monospace; }
        .piatki-wynik-ujemny { background-color: #fed7aa !important; }
        .piatki-margin-wysoki { background-color: #bbf7d0 !important; }
    </style>

    <div class="table-wrap overflow-x-auto">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Nazwa</th>
                    <th class="text-right">Przychód</th>
                    <th class="text-right">Koszt</th>
                    <th class="text-right">Wynik</th>
                    <th class="text-right">% margin</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $grupy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nazwa => $grupa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $przychod = $grupa['ma3'];
                    $koszt = $grupa['wn3'];
                    $wynik = $przychod - $koszt;
                    $pctMargin = $przychod != 0 ? round(($wynik / $przychod) * 100, 1) : null;
                ?>
                <tr>
                    <td>
                        <?php if(count($grupa['szczegoly']) > 0): ?>
                        <span class="piatki-expand" role="button" tabindex="0" onclick="document.getElementById('piatki-details-<?php echo e($loop->index); ?>').classList.toggle('piatki-details-widoczne'); this.textContent = this.textContent === '>' ? 'v' : '>'" title="Pokaż szczegóły">&gt;</span>
                        <?php endif; ?>
                        <?php echo e($nazwa); ?>

                    </td>
                    <td class="text-right piatki-num"><?php echo e(number_format($przychod, 2, ',', ' ')); ?></td>
                    <td class="text-right piatki-num"><?php echo e(number_format($koszt, 2, ',', ' ')); ?></td>
                    <td class="text-right piatki-num <?php echo e($wynik < 0 ? 'piatki-wynik-ujemny' : ''); ?>"><?php echo e(number_format($wynik, 2, ',', ' ')); ?></td>
                    <td class="text-right piatki-num <?php echo e($pctMargin !== null && $pctMargin > 50 ? 'piatki-margin-wysoki' : ''); ?>"><?php echo e($pctMargin !== null ? number_format($pctMargin, 1, ',', ' ') . '%' : '—'); ?></td>
                </tr>
                <tr id="piatki-details-<?php echo e($loop->index); ?>" class="piatki-details-row">
                    <td colspan="5" class="piatki-details-cell">
                        <table class="piatki-details-table">
                            <thead><tr><th>Nr</th><th class="text-right">Przychód</th><th class="text-right">Koszt</th><th class="text-right">Wynik</th><th class="text-right">% margin</th></tr></thead>
                            <tbody>
                                <?php $__currentLoopData = $grupa['szczegoly']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $sp = $s['ma3'];
                                    $sk = $s['wn3'];
                                    $sw = $sp - $sk;
                                    $spct = $sp != 0 ? round(($sw / $sp) * 100, 1) : null;
                                ?>
                                <tr>
                                    <td><?php echo e($s['nr']); ?></td>
                                    <td class="text-right piatki-num"><?php echo e(number_format($sp, 2, ',', ' ')); ?></td>
                                    <td class="text-right piatki-num"><?php echo e(number_format($sk, 2, ',', ' ')); ?></td>
                                    <td class="text-right piatki-num <?php echo e($sw < 0 ? 'piatki-wynik-ujemny' : ''); ?>"><?php echo e(number_format($sw, 2, ',', ' ')); ?></td>
                                    <td class="text-right piatki-num <?php echo e($spct !== null && $spct > 50 ? 'piatki-margin-wysoki' : ''); ?>"><?php echo e($spct !== null ? number_format($spct, 1, ',', ' ') . '%' : '—'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/piotr/Documents/3.SOFTWARE/_syto/valo/resources/views/piatki/show.blade.php ENDPATH**/ ?>